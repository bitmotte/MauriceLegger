# Maurice Legger Mod
### Best experienced with [Maurice Baller Mod](https://thunderstore.io/c/ultrakill/p/bitmotte/MauriceBaller/).

Maurices have legs,like a cerberus . . . Very tiny mod,comes with a few useful config .

It also comes with 4 rare variation . . . Can you find them all ?
\
\
\
Idea from [this video](https://youtu.be/8GUCSL4jrUA?si=NwnTC1YyzqDGuwNs) . . .
### Any issue,question,or concern ? [Contact me on reddit](https://www.reddit.com/user/bitmotte/) .
