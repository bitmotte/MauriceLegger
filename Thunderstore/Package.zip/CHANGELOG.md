# 2.0.1
- Make variations rare ( i forgot to set it back )

# 2.0.0
- Added new secret variation
- Maurices now sit down when near ground
- Fixed a bug where some maurices in a 1-3 arena would break

# 1.0.0
- Release
